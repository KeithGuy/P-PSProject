#include <iostream>
#include <string>
#include <string.h>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sstream>


using namespace std;

//Class to set rules of game

class GameRules{
public:

    void Welcome(){
        cout<<"\n\n\t\t Welcome to Monopoly!\n\n";
    }
    void ShowRules(){
        cout<<"\n\t Please read the rules listed below: \n\n";
        cout<<"\t -If a player is to land on a property that is for sale, that property is purchased automatically.\n";
        cout<<"\t -If a player is to land on a property that is sold, rent is due to the respective owner.\n";
        cout<<"\t -If a player is to land on a railroad, nothing occurs.\n";
        cout<<"\t -If a player is to roll doubles sixes, player rolls again.\n";
        cout<<"\t -If a player is to roll doubles sixes 3 times in a row, then the player goes to jail.\n";
        cout<<"\t -If a player's balance is to reach 0, they are out of the game, other players are to continue.\n";
        cout<<"\t -If a player is to land on a community chest or chance (on cards), do as the card says. \n";
        cout<<"\t -If a player is to pass go, add $200 to player's balance.\n\n\n\n";
    }
};


//Game Cell Class
class GameCell{
private:
    string status;  //variables
    int price;
    int rent;
    string owner;
    string name;
public:
    GameCell(){ //constructor
        status = "nope" ;
        price = 0 ;
        rent = 0 ;
        owner = "no";
        name = "GO" ;
    }
    GameCell(string st, string n,int pr, int rnt){
        status = st ;
        price = pr ;
        rent = rnt ;
        owner = "no";
        name = n ;

    }

    // getters
    string  GetStatus(){
        return status;
    }
    string  GetName(){
        return name;
    }
    int  GetPrice(){
        return price;
    }
    int  GetRent(){
        return rent;
    }
    string  GetOwner(){
        return owner;
    }
    //setters
    void  setStatus(string s){
        status = s ;
    }
    void  setName(string n){
        name = n ;
    }
    void  setPrice(int pr){
        price = pr ;
    }
    void setRent(int rnt){
        rent = rnt ;
    }
    void  setOwner(string s){
        owner = s ;
    }


};


//Property Class
class Player{

private:

    string name;
    int balance;
    string life_status;
    int currentPosition;
public:
    Player(){ // Constructor
        //Set initial limit of 1500 dollars
        balance = 1500 ;
        life_status = "alive";
        currentPosition = 0 ; //position
    }

    // parameterized constructor
    Player( string Name, string life){
        name = "Luffy " ;
        life_status = "alive" ;
        balance = 1500 ;
        currentPosition = 0 ;
    }

    //display values function
    void Display()
    {
        cout<<"Name is "<<name<<endl;
        cout<<"Amount is "<<balance<<endl;
        cout<<"Life status is "<<life_status<<endl;
        cout<<"\n\n";
    }

    //setters
    void SetName(string n){
        name = n;
    }
    void SetStatus(string st){
        life_status = st ;
    }
    void SetBalance(int b){
        balance = b ;
    }
    void SetCurrentPosition(int p){
        currentPosition = p ;
    }
    //getters
    string getName(){
        return name ;
    }
    string getStatus(){
        return life_status  ;
    }
    int getBalance(){
        return balance;
    }
    int getCurrentPosition(){
        return currentPosition;
    }

//updating functions
    // function to update the player's balance
    void AddBalance(int b){
        balance = balance + b ;
    }
    // function to subtract value from player's balance
    void SubtractBalance(int b){
        balance = balance - b ;
    }

    // function to update the player's name
    void UpdateStatus (string st){
        life_status = st ;
    }

};




//Game Class
class Monopoly{

public:
    int no_of_players;
    bool outFromJail;
    bool goToJail;
    int count;


    Monopoly() //constructor
    {

        outFromJail = false ;
        goToJail = false ;
        count=0;

    }
    //get initial data function
    void StartMonopoly(GameCell cellObject[])
    {
        GetPlayersNumber() ; // calling function to get total players
        cout << ("-----------------------------------------------------------------------");
        GameRules rules; //displays welcome
        rules.Welcome();
        GetPlayerNames(cellObject) ;  //retrieves players names


    }

    // input number of players
    void GetPlayersNumber(){

        cout<<" \tPlease enter the number of players between 2 and 8, then press Enter. \n";
        cin>> no_of_players;
        cout<<"\tEntered players are:"<<no_of_players<<endl;
        cout<<endl;
    }
    void GetPlayerNames(GameCell cellObject[]){
        string name;
        //create array of players
        Player playerObject[no_of_players] ;
        cout <<"\n\n\n\t\tPlease enter player names one after another, then press Enter.\n";
        //set player's object data
        for (int i = 0 ; i < no_of_players ; i ++){
            cin >>name;
            playerObject[i].SetName(name);
        }
        //display data
        for (int i = 0 ; i < no_of_players ; i ++){

            playerObject[i].Display();
            playerObject[i].Display();
        }
        //chose first turn
        cout << ("-----------------------------------------------------------------------");
        ShowPlayerrTurnNumber(playerObject);
        PlayGame(playerObject,cellObject);


    }//end


    //show player's turn number
    void ShowPlayerrTurnNumber( Player array[] ){
        cout<<"\n\n\n";
        cout<<"  Player order is determined by order of players names entered. \n";
        sleep(2);
        cout << ("-----------------------------------------------------------------------");
        for (int i = 0 ; i < no_of_players ; i ++){

            cout<<"  player "<<array[i].getName()<<" turn number is :"<<i+1<<endl;
        }
        sleep(2);
        cout << ("-----------------------------------------------------------------------");

    }

    // roll dice function
    int  DiceRoll(){
        int firstDice = 0 ;
        int secondDice = 0 ;
        int die;

        srand (time(NULL));
        //generate random number for each die
        die = rand() % 6 + 1;
        firstDice = die ;
        die = rand() % 6 + 1;
        secondDice = die ;
        if (firstDice == secondDice)
            outFromJail = true ;

        if (firstDice == 6 &&  secondDice == 6)
        { cout<<"\t\t\t dice results: dice 1 number is : "<<firstDice<<"  dice 2 number is :"<<secondDice;
            return 1;
        }
        else{
            cout<<"\t\t\t dice results: dice 1 number is : "<<firstDice<<"  dice 2 number is :"<<secondDice;
            return firstDice + secondDice ;
        }



    } // dice roll is ends here


    // return dice results function
    int GetDiceResults(){

        int result = 0 ;
        int again = 0 ;
        again = DiceRoll() ;
        result = again ;
        if ( again == 1 ) // means dice values are equal, doubles roll again
        {
            cout << " dice are equals, doubles. please roll again \n ";
            result = 12 ;
            again = DiceRoll() ; //2 time
            if ( again == 1 ) // if double sixes
            {  cout << " doubles again! please roll dice again\n ";
                result = result + 12 ;
                again = DiceRoll() ; //2 time
                if( again == 1 ){ //if double sixes
                    cout << " doubles 3 times!! wow. go to jail lol\n ";
                    goToJail = true;
                    return 0;
                }
                else{
                    cout << "  total of 2 dice is : "<< result <<endl;
                    return result + again ;
                }

            }
            else {
                cout << "  total of 2 dice is : "<< result <<endl;
                return result + again ;
            }
        }
        else{
            cout << "  total of 2 dice is : "<< result <<endl;
            return result;
        }
    }//end




    int PlayGame(Player array[], GameCell cellObject[]){
        int cardsmoney = 0;
        int playerFlag[no_of_players];
        int total_turn = no_of_players ;
        int size=no_of_players;
        for (int i = 0 ; i < no_of_players ; i ++){
            playerFlag[i]=1;
        }
        bool start = true;
        int number = 0 ;
        int pos=0;// to set current position of player
        ofstream outdata; 	//output to text file
        outdata.open("output.txt"); // opens the file
        if( !outdata ) { // file couldn't be opened
            cerr << "Error: file could not be opened" << endl;
            exit(1);
        }

        int secure = 0;
        int player = no_of_players ;
        DisplayGameBoard(cellObject); // calling function to display gameboard
        cout<<"\n\n\n";
        int i= 0;
        //start playing
        while ( i < total_turn){
            if (playerFlag[i]==1) // if player balance is not zero
            {
                pos = array[i].getCurrentPosition();
                cout<<" -"<<array[i].getName()<<"  turn  | Balance =$"<<array[i].getBalance()<<" \n";
                number = GetDiceResults();
                secure = number ;
                cout<<array[i].getName()<<"  dice result is : "<<number;
                number = number + pos ;
                array[i].SetCurrentPosition (number);
                //check if index out of bound >40
                if (number > 39){
                    number = secure ;
                    array[i].SetCurrentPosition (number);
                }
                cout<<" player must move to that index by adding to current index : "<<number<<endl;


                //player auto buying property
                if (cellObject[number].GetName() == "property" && cellObject[number].GetStatus() == "free") //
                {   if (array[i].getBalance() >= cellObject[number].GetPrice()){
                        int price = 0;
                        price = cellObject[number].GetPrice();
                        array[i].SubtractBalance(price) ; // updating the balance of player
                        cellObject[number].setStatus("sold");
                        cellObject[number].setRent(50);
                        // convert i into string and put that in array
                        stringstream ss;
                        ss << i;
                        string str;
                        ss >> str;

                        cellObject[number].setOwner(str); // owner id set
                        cout<<" player landed on a property free, purchasing that property\n";
                        outdata << array[i].getName() <<" dice result ="<<secure<< " --landed on free property-- buy " <<" property  || paid amount is = "<<price<<" || current balance = $"<<array[i].getBalance()<<endl;
                        count = count + 1 ;
                        i +=1;
                    }


                }
                    //if player land on already bought property, then the player will pay rent to owner
                else if (cellObject[number].GetName() == "property" && cellObject[number].GetStatus() == "sold") //
                {    if (array[i].getBalance() >= cellObject[number].GetPrice()){
                        int rent = 0;
                        rent = cellObject[number].GetPrice()*.75;
                        array[i].SubtractBalance(rent) ; // update balance of player after paying rent
                        cellObject[number].setStatus("on rent");
                        cellObject[number].setRent(50);
                        string str= cellObject[number].GetOwner(); //converting ot string
                        stringstream geek(str);
                        int k=0;
                        geek >> k;

                        cout<<"player landed on a property already sold, please pay rent to owner\n";
                        if (array[i].getName() != array[k].getName()){ // if both players are not same
                            outdata << array[i].getName() << " dice result ="<<secure<<" landed on already sold property  || paid rent  ="<<rent<<"| to | "<< array[k].getName()<<" || current balance =$ "<<array[i].getBalance()<< endl;
                            count = count + 1 ;
                            i +=1;
                            array[k].AddBalance(rent) ;
                        }
                        else if (array[i].getName() == array[k].getName()){ // if both players are same
                            outdata << array[i].getName() << " dice result ="<<secure<<" landed on already sold property  || but owner is current player  | no need to pay rent || current balance =$ "<<array[i].getBalance()<< endl;
                            count = count + 1 ;
                            i +=1;
                        }



                    }

                }
                    //add 200 to money when player passes go
                else if (cellObject[number].GetName() == "GO" ) //
                {

                    if(start==false){

                        array[i].AddBalance(200) ; // update balance of player after passing GO
                        outdata << array[i].getName() << " dice result ="<<secure<<" 'passes GO" <<" & get $200 || new balance is =$ "<<array[i].getBalance()<< endl;
                        count = count + 1 ;
                        i +=1;
                    }
                    else if(start==true){
                        count = count + 1;
                        i +=1;
                        outdata << array[i].getName() << " dice result ="<<secure<<" 'passes GO" <<" & but game in start || new balance is =$ "<<array[i].getBalance()<< endl;
                    }

                }
                    //if player lands on "go to jail", then sent player to jail
                else if (cellObject[number].GetName() == "Go to Jail" ) //
                {

                    array[i].SetStatus("in jail");
                    outdata << array[i].getName() << " dice result ="<<secure<<" landed on  new landed on in jail || sent to Jail"<< endl;
                    count = count + 1 ;
                    i +=1;
                }
                    //Community Chest and chance cards
                else if (cellObject[number].GetName() == "COMMUNITY CHEST" || cellObject[number].GetName() == "Chance" ) //
                {   if (array[i].getBalance() >= 1){
                        cardsmoney = ((rand() %10 +1)*50);
                        array[i].SubtractBalance(cardsmoney); // update balance of player
                        outdata << array[i].getName() << " dice result ="<<secure<<" on cards" <<" pay $"<<cardsmoney<<" || current balance =$"<<array[i].getBalance()<< endl;
                        count = count + 1 ;
                        i +=1;
                    }

                }
                    //tax
                else if (cellObject[number].GetName() == "tax"  ) //
                {    if (array[i].getBalance() >= cellObject[number].GetPrice()){
                        int rent = 0;
                        rent = cellObject[number].GetPrice();
                        array[i].SubtractBalance(rent) ; // updates balance of player after paying tax

                        cout<<"Player has landed on a tax.\n";
                        outdata << array[i].getName() <<" dice result ="<<secure<< " landed on tax  || paid tax ="<<rent<<" || current balance =$ "<<array[i].getBalance()<< endl;
                        count = count + 1 ;
                        i +=1;
                    }

                }
                else if (cellObject[number].GetName() == "Railway" )
                {

                    cout<<" on railway \n";
                    outdata << array[i].getName() << " dice result ="<<secure<<" on railway" <<" do nothing || current balance =$"<<array[i].getBalance()<< endl;
                    count = count + 1 ;
                    i +=1;
                }

            } //ends
            else if (playerFlag[i]==0){
                i=i+1;
                count=count+1;
            }

            sleep(2);
            cout << ("-----------------------------------------------------------------------");

            cout<<"Next players turn"<<endl;
            sleep(2);
            cout << ("-----------------------------------------------------------------------");

            if (count == total_turn  ) {// next round logic
                start = false ;
                i = 0 ;
                int temp = count;
                int z= temp -count;
                count=z;
                int reducePlayer = 0;
                for (int j = 0 ; j < no_of_players ; j ++){
                    if(array[j].getBalance() <=0 ){ //check all three players balance or status
                        playerFlag[j]=0; //not allow to play that player
                        reducePlayer = reducePlayer + 1 ;//reduce by one player
                        outdata << array[j].getName() << " || balance = 0 || lost the game " <<endl;
                    }





                } //setting players status
                no_of_players = no_of_players - reducePlayer; // remaining players
                total_turn = no_of_players ; // turns updated

                //print winning conditions
                if (no_of_players == 1)
                {
                    for (int k = 0 ; k < size ; k++ ){
                        if (playerFlag[k] == 1) // not loose
                        {
                            if (array[k].getStatus()!="in jail"){ // not in jail
                                cout<<"\t\tOne player remaining, Game Over!\n";
                                cout<<array[k].getName()<<"\t\t WON\n";
                                outdata << array[k].getName() << " || Wins! || GAME OVER " << endl;
                                return 0;
                            }
                            else if (array[k].getStatus() =="in jail"){ // in jail
                                cout<<"\t\t  game over\n";
                                cout<<array[k].getName()<<"\t\t No one wins. \n";
                                outdata << array[k].getName() << " in jail || DRAW || GAME OVER " << endl;
                                return 0;
                            }
                        }

                    }
                } //check if single player
                sleep(1);
            }
        } //main for loop
        return 0;

    }


    //display gameboard
    void DisplayGameBoard(GameCell array[]){
        for (int i = 0 ; i < 40 ; i ++){ //display board
            cout<<"| ";
            cout<<array[i].GetName();
            if (array[i].GetName() == "Property" || array[i].GetName() == "Tax" )
                cout<<"="<<array[i].GetPrice();
            if (array[i].GetName() == "In Jail" )
                cout<<endl;
            if (array[i].GetName() == "Parking" )
                cout<<endl;
            if (array[i].GetName() == "Go to Jail" )
                cout<<endl;
        }
    }//end
};




//game board properties class
class GameBoard{
public:
    int totalCells;
    GameBoard(){
        totalCells = 40 ;
        GenerateGameBoard();
    }
    //create the game board
    void GenerateGameBoard(){

        GameCell cellObject[totalCells];
        for (int i = 0 ; i < totalCells ; i ++){ //setting rent & owner initial to 0 and no
            cellObject[i].setRent(0);
            cellObject[i].setOwner("no");
            cellObject[i].setStatus("nope");
        }
        cellObject[0].setName("GO");
        cellObject[0].setPrice(0);
        cellObject[1].setName("property");
        cellObject[1].setPrice(60);
        cellObject[2].setName("COMMUNITY CHEST");
        cellObject[2].setPrice(0);
        cellObject[3].setName("property");
        cellObject[3].setPrice(60);
        cellObject[4].setName("tax");
        cellObject[4].setPrice(200);
        cellObject[5].setName("Railway");
        cellObject[5].setPrice(0);
        cellObject[6].setName("property");
        cellObject[6].setPrice(100);
        cellObject[7].setName("Chance");
        cellObject[7].setPrice(0);
        cellObject[8].setName("property");
        cellObject[8].setPrice(100);
        cellObject[9].setName("property");
        cellObject[9].setPrice(120);
        cellObject[10].setName("In Jail");
        cellObject[10].setPrice(0);
        cellObject[11].setName("property");
        cellObject[11].setPrice(140);
        cellObject[12].setName("property");
        cellObject[12].setPrice(150);
        cellObject[13].setName("property");
        cellObject[13].setPrice(140);
        cellObject[14].setName("property");
        cellObject[14].setPrice(160);
        cellObject[15].setName("Railway");
        cellObject[15].setPrice(0);
        cellObject[16].setName("property");
        cellObject[16].setPrice(180);
        cellObject[17].setName("COMMUNITY CHEST");
        cellObject[17].setPrice(0);
        cellObject[18].setName("property");
        cellObject[18].setPrice(180);
        cellObject[19].setName("property");
        cellObject[19].setPrice(200);
        cellObject[20].setName("Parking");
        cellObject[20].setPrice(0);
        cellObject[21].setName("property");
        cellObject[21].setPrice(220);
        cellObject[22].setName("Chance");
        cellObject[22].setPrice(0);
        cellObject[23].setName("property");
        cellObject[23].setPrice(220);
        cellObject[24].setName("property");
        cellObject[24].setPrice(240);
        cellObject[25].setName("Railway");
        cellObject[25].setPrice(0);
        cellObject[26].setName("property");
        cellObject[26].setPrice(260);
        cellObject[27].setName("property");
        cellObject[27].setPrice(260);
        cellObject[28].setName("property");
        cellObject[28].setPrice(150);
        cellObject[29].setName("property");
        cellObject[29].setPrice(280);
        cellObject[30].setName("Go to Jail");
        cellObject[30].setPrice(0);
        cellObject[31].setName("property");
        cellObject[31].setPrice(300);
        cellObject[32].setName("property");
        cellObject[32].setPrice(300);
        cellObject[33].setName("COMMUNITY CHEST");
        cellObject[33].setPrice(0);
        cellObject[34].setName("property");
        cellObject[34].setPrice(320);
        cellObject[35].setName("Railway");
        cellObject[35].setPrice(0);
        cellObject[36].setName("Chance");
        cellObject[36].setPrice(0);
        cellObject[37].setName("property");
        cellObject[37].setPrice(350);
        cellObject[38].setName("tax");
        cellObject[38].setPrice(100);
        cellObject[39].setName("property");
        cellObject[39].setPrice(400);
        for (int i = 0 ; i < totalCells ; i ++){ //setting rent & owner initial to 0 and no
            if (cellObject[i].GetName() == "property")
                cellObject[i].setStatus("free");
        }
        Monopoly object;
        object.StartMonopoly(cellObject);

    }
    //displays gameboard
    void DisplayGameBoard(GameCell array[]){
        for (int i = 0 ; i < totalCells ; i ++){ //display board
            cout<<"| ";
            cout<<array[i].GetName();
            if (array[i].GetName() == "property" || array[i].GetName() == "tax" )
                cout<<"="<<array[i].GetPrice();
            if (array[i].GetName() == "In Jail" )
                cout<<endl;
            if (array[i].GetName() == "Parking" )
                cout<<endl;
            if (array[i].GetName() == "Go to Jail" )
                cout<<endl;
        }
    }

};


//main function
int main()
{
    GameRules rules;
    rules.Welcome();
    rules.ShowRules();
    GameBoard k;

    return 0;
}

